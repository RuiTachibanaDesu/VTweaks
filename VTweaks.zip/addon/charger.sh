check_battery() {
# Mengambil level baterai
battery_level=$(dumpsys battery | grep "level" | awk '{print $2}')

# Memeriksa apakah baterai mencapai 90%
if [ "$battery_level" -ge 93 ]; then
    # Menjalankan script jika baterai mencapai 90%
    echo "Level baterai mencapai 90% atau lebih"
chmod 0777 /sys/class/power_supply/battery/constant_charge_current_max
echo 2300000 > /sys/class/power_supply/battery/constant_charge_current_max
chmod 0644 /sys/class/power_supply/battery/constant_charge_current_max
sleep 10
looopping
else
    echo "Level baterai kurang dari 93%"
    sleep 10
chmod 0777 /sys/class/power_supply/battery/constant_charge_current_max
echo 5300000 > /sys/class/power_supply/battery/constant_charge_current_max
chmod 0644 /sys/class/power_supply/battery/constant_charge_current_max
    looopping
fi
}

looopping() {
# Perulangan untuk menjalankan pengecekan setiap 10 detik
while true; do
    check_battery  # Memanggil fungsi pengecekan baterai
    sleep 10       # Menunggu selama 10 detik sebelum pengecekan selanjutnya
done
}

looopping