bypass_suhu() {
for K in {0,1,2,3,4,5,6,7}

set_value() {
  if [[ -f "$1" ]];
  then
    chmod 0666 "$1"
    echo "$2" > "$1"
  fi
}

chpacth=' /sys/devices/system/cpu/cpu$K/cpufreq/scaling_governor'

Suhu=$(dumpsys battery | grep "temp" | awk '{print $2}')


if [ "$Suhu" -ge 610 ]; then
    set_value $chpacth powersave
else
    set_value $chpacth performance
fi
}

check_battery() {

set_value() {
  if [[ -f "$1" ]];
  then
    chmod 0666 "$1"
    echo "$2" > "$1"
  fi
}

bce='/sys/class/power_supply/battery/battery_charging_enabled'
suspend='/sys/class/power_supply/battery/input_suspend'
suspend2='/sys/class/qcom-battery/input_suspend'

battery_level=$(dumpsys battery | grep "level" | awk '{print $2}')
# Memeriksa apakah baterai mencapai 90%
if [ "$battery_level" -ge 97 ]; then
    # Menjalankan script jika baterai mencapai 90%
    echo "Level baterai mencapai 97% atau lebih"
     set_value $bce 0
     set_value $suspend 1
     set_value $suspend2 1
    sleep 3
    set_value /sys/class/qcom-battery/restricted_charging 0
    # set_value /sys/class/power_supply/battery/step_charging_enabled 0
    set_value /sys/class/power_supply/usb/boost_current 0
    set_value /sys/class/power_supply/battery/restricted_charging 0
    # set_value /sys/class/power_supply/usb/pd_allowed 1
    set_value /sys/class/power_supply/allow_hvdcp3 1
    # set_value /sys/class/power_supply/battery/subsystem/usb/pd_allowed 1
    set_value /sys/class/power_supply/battery/safety_timer_enabled 1
    set_value /sys/class/power_supply/bms/temp_warm 400
    looopping
else
    echo "Level baterai kurang dari 97%"
     set_value $bce 1
     set_value $suspend 0
     set_value $suspend2 0
     sleep 3
    set_value /sys/class/qcom-battery/restricted_charging 0
    # set_value /sys/class/power_supply/battery/step_charging_enabled 0
    set_value /sys/class/power_supply/usb/boost_current 1
    set_value /sys/class/power_supply/battery/restricted_charging 0
    # set_value /sys/class/power_supply/usb/pd_allowed 1
    set_value /sys/class/power_supply/allow_hvdcp3 1
    # set_value /sys/class/power_supply/battery/subsystem/usb/pd_allowed 1
    set_value /sys/class/power_supply/battery/safety_timer_enabled 0
    set_value /sys/class/power_supply/bms/temp_warm 610
     looopping
fi
}

looopping() {
# Perulangan untuk menjalankan pengecekan setiap 10 detik
while true; do
    check_battery  # Memanggil fungsi pengecekan baterai
    sleep 1
    bypass_suhu
    sleep 5 # Menunggu selama 10 detik sebelum pengecekan selanjutnya
done
}

fastcharger() {
limit_value=$1
# 是否只往上加
only_taller=$2

if [[ "$limit_value" = "" ]]
then
    limit_value=5000
fi

device=$(getprop ro.product.device)
# Xiaomi 11Pro/Ultra
if [[ "$device" == "mars" ]] || [[ "$device" == "star" ]]; then
  echo "${1}000" > /sys/class/power_supply/battery/constant_charge_current
  return
fi

paths=`ls /sys/class/power_supply/*/constant_charge_current_max`

# 更改限制 change_limit ?mA
change_limit() {
    echo "更改限制值为：${1}mA"
    local limit="${1}000"

    for path in $paths
    do
        chmod 0664 $path
        if [[ "$only_taller" = 1 ]]; then
            local current_limit=`cat $path`
            if [[ "$current_limit" -lt "$limit" ]]; then
                echo $limit > $path
            fi
        else
            echo $limit > $path
        fi
    done
}

change_limit $limit_value
}


fastcharger
sleep 1
looopping