
#kill sensor
sleep 1

stop logd

sleep 10

for thermal in $(resetprop | awk -F '[][]' '/thermal/ {print $2}'); do
  if [[ $(resetprop "$thermal") == running ]] || [[ $(resetprop "$thermal") == restarting ]]; then
    stop "${thermal/init.svc.}"
    sleep 10
    resetprop -n "$thermal" stopped
  fi
done

sleep 10

find /sys/devices/virtual/thermal -type f -exec chmod 000 {} +
sleep 1
#perf dikit
cat /dev/cpuset/background/cpus;
echo '0-1' > /dev/cpuset/background/cpus;
restorecon -R /dev/cpuset/background/cpus;
chmod 777 /dev/cpuset/foreground/cpus;
chown root /dev/cpuset/foreground/cpus;
chgrp root /dev/cpuset/foreground/cpus;
chmod 777 /dev/cpuset/foreground/effective_cpus;
chown root /dev/cpuset/foreground/effective_cpus;
chgrp root /dev/cpuset/foreground/effective_cpus;
cat /dev/cpuset/foreground/cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/cpus;
restorecon -R /dev/cpuset/foreground/cpus;
cat /dev/cpuset/foreground/effective_cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/effective_cpus;
restorecon -R /dev/cpuset/foreground/effective_cpus;
cat /dev/cpuset/restricted/cpus;
echo '0-3' > /dev/cpuset/restricted/cpus;
restorecon -R /dev/cpuset/restricted/cpus;
cat /dev/cpuset/system-background/cpus;
echo '0-3' > /dev/cpuset/system-background/cpus;
restorecon -R /dev/cpuset/system-background/cpus;
cat /dev/cpuset/top-app/cpus;
echo '0-7' > /dev/cpuset/top-app/cpus;
restorecon -R /dev/cpuset/top-app/cpus;
cat /dev/cpuset/top-app/effective_cpus;
echo '0-7' > /dev/cpuset/top-app/effective_cpus;
restorecon -R /dev/cpuset/top-app/effective_cpus;
echo '5' > /dev/stune/schedtune.boost;
echo '1' > /dev/stune/schedtune.prefer_idle;
echo '0' > /dev/stune/schedtune.colocate;
echo '10' > /dev/stune/schedtune.sched_boost;
echo '5' > /dev/stune/background/schedtune.boost;
echo '1' > /dev/stune/background/schedtune.prefer_idle;
echo '0' > /dev/stune/background/schedtune.colocate;
echo '10' > /dev/stune/background/schedtune.sched_boost;
echo '5' > /dev/stune/foreground/schedtune.boost;
echo '1' > /dev/stune/foreground/schedtune.prefer_idle;
echo '0' > /dev/stune/foreground/schedtune.colocate;
echo '10' > /dev/stune/foreground/schedtune.sched_boost;
echo '30' > /dev/stune/rt/schedtune.boost;
echo '1' > /dev/stune/rt/schedtune.prefer_idle;
echo '0' > /dev/stune/rt/schedtune.colocate;
echo '10' > /dev/stune/rt/schedtune.sched_boost;
echo '30' > /dev/stune/top-app/schedtune.boost;
echo '1' > /dev/stune/top-app/schedtune.prefer_idle;
echo '0' > /dev/stune/top-app/schedtune.colocate;
echo '10' > /dev/stune/top-app/schedtune.sched_boost;
echo '14044220' > /sys/class/kgsl/kgsl/full_cache_threshold;
echo '0' > /sys/class/kgsl/kgsl-3d0/force_clk_on;
echo '0' > /sys/class/kgsl/kgsl-3d0/force_bus_on;
echo '0' > /sys/class/kgsl/kgsl-3d0/force_rail_on;
echo '0' > /sys/class/kgsl/kgsl-3d0/force_no_nap;
echo '80' > /sys/class/kgsl/kgsl-3d0/idle_timer;
echo '0' > /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel;
echo '1' > /sys/class/kgsl/kgsl-3d0/throttling;
echo '1' > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost;
sleep 1
write /sys/kernel/gpu/gpu_governor performance
sleep 1
echo 0 > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
echo 0 > /sys/module/msm_performance/parameters/touchboost
cat /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_clk_on;
echo '0' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_clk_on;
restorecon -R /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_clk_on;
cat /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_bus_on;
echo '0' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_bus_on;
restorecon -R /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_bus_on;
cat /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_rail_on;
echo '0' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_rail_on;
restorecon -R /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_rail_on;
cat /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_no_nap;
echo '0' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_no_nap;
restorecon -R /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_no_nap;
cat /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/idle_timer;
echo '80' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/idle_timer;
restorecon -R /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/idle_timer;
cat /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/thermal_pwrlevel;
echo '0' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/thermal_pwrlevel;
restorecon -R /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/thermal_pwrlevel;
cat /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/throttling;
echo '1' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/throttling;
restorecon -R /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/throttling;
cat /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/devfreq/adrenoboost;
echo '1' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/devfreq/adrenoboost;
restorecon -R /sys/class/devfreq/5000000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/devfreq/adrenoboost;
cat /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_clk_on;
echo '0' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_clk_on;
restorecon -R /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_clk_on;
cat /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_bus_on;
echo '0' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_bus_on;
restorecon -R /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_bus_on;
cat /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_rail_on;
echo '0' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_rail_on;
restorecon -R /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_rail_on;
cat /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_no_nap;
echo '0' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_no_nap;
restorecon -R /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/force_no_nap;
cat /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/idle_timer;
echo '80' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/idle_timer;
restorecon -R /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/idle_timer;
cat /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/thermal_pwrlevel;
echo '0' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/thermal_pwrlevel;
restorecon -R /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/thermal_pwrlevel;
cat /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/throttling;
echo '1' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/throttling;
restorecon -R /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/throttling;
cat /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/devfreq/adrenoboost;
echo '1' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/devfreq/adrenoboost;
restorecon -R /sys/class/devfreq/5900000.qcom,kgsl-3d0/device/kgsl/kgsl-3d0/devfreq/adrenoboost;
cat /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_clk_on;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_clk_on;
restorecon -R /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_clk_on;
cat /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_bus_on;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_bus_on;
restorecon -R /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_bus_on;
cat /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_rail_on;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_rail_on;
restorecon -R /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_rail_on;
cat /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_no_nap;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_no_nap;
restorecon -R /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/force_no_nap;
cat /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/idle_timer;
echo '80' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/idle_timer;
restorecon -R /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/idle_timer;
cat /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/thermal_pwrlevel;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/thermal_pwrlevel;
restorecon -R /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/thermal_pwrlevel;
cat /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/throttling;
echo '1' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/throttling;
restorecon -R /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/throttling;
cat /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/devfreq/adrenoboost;
echo '1' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/devfreq/adrenoboost;
restorecon -R /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/devfreq/adrenoboost;
cat /sys/module/adreno/parameters/true_gpu;
echo 'N' > /sys/module/adreno/parameters/true_gpu;
restorecon -R /sys/module/adreno/parameters/true_gpu;
sleep 5

for i in /sys/class/kgsl/kgsl-3d0 ; do

	echo 0 > $i/thermal_pwrlevel
    echo 0 > $i/throttling 
    echo 0 > $i/max_pwrlevel
    echo 0 > $i/perfcounter
    echo 1 > $i/force_clk_on
    echo 0 > $i/force_bus_on
    echo 1 > $i/force_rail_on
    echo 1 > $i/force_no_nap
    echo 1 > $i/bus_split

done;

# Fast Sensivity in Game
write /dev/stune/background/schedtune.boost "20"
write /dev/stune/background/schedtune.prefer_idle "0"
write /dev/stune/background/schedtune.colocate "0"
write /dev/stune/background/schedtune.sched_boost_enabled "0"

write /dev/stune/foreground/schedtune.boost "20"
write /dev/stune/foreground/schedtune.prefer_idle "0"
write /dev/stune/foreground/schedtune.colocate "0"
write /dev/stune/foreground/schedtune.sched_boost_enabled "0"

write /dev/stune/rt/schedtune.boost "20"
write /dev/stune/rt/schedtune.prefer_idle "0"
write /dev/stune/rt/schedtune.colocate "0"
write /dev/stune/rt/schedtune.sched_boost_enabled "0"

write /dev/stune/top-app/schedtune.boost "20"
write /dev/stune/top-app/schedtune.prefer_idle "0"
write /dev/stune/top-app/schedtune.colocate "0"
write /dev/stune/top-app/schedtune.sched_boost_enabled "0"

write /dev/stune/schedtune.boost "20"
write /dev/stune/schedtune.prefer_idle "0"
write /dev/stune/schedtune.colocate "0"
write /dev/stune/schedtune.sched_boost_enabled "0

sleep 1

# Disable Core control / hotplug

for i in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl ; do
    chmod 666 $i/enable
	echo 0 > $i/enable
	chmod 444 $i/enable
done ;

#I/O 
echo 'deadline' > /sys/block/mmcblk0/queue/scheduler
echo 'deadline' > /sys/block/mmcblk1/queue/scheduler
echo '1024' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '1024' > /sys/block/mmcblk1/queue/read_ahead_kb
echo "75" > /sys/devices/system/cpu/cpufreq/performance/up_threshold
echo "40000" > /sys/devices/system/cpu/cpufreq/performance/sampling_rate
echo "5" > /sys/devices/system/cpu/cpufreq/performance/sampling_down_factor
echo "20" > /sys/devices/system/cpu/cpufreq/performance/down_threshold
echo "25" > /sys/devices/system/cpu/cpufreq/performance/freq_step/sys/class/kgsl/kgsl-3d0/devfreq/governor
echo "deadline" > /sys/block/sda/queue/scheduler
echo "1024" > /sys/block/sda/queue/read_ahead_kb
echo "0" > /sys/block/sda/queue/rotational
echo "0" > /sys/block/sda/queue/iostats
echo "0" > /sys/block/sda/queue/add_random
echo "1" > /sys/block/sda/queue/rq_affinity
echo "0" > /sys/block/sda/queue/nomerges
echo "1024" > /sys/block/sda/queue/nr_requests
echo "deadline" > /sys/block/sdb/queue/scheduler
echo "1024" > /sys/block/sdb/queue/read_ahead_kb
echo "0" > /sys/block/sdb/queue/rotational
echo "0" > /sys/block/sdb/queue/iostats
echo "0" > /sys/block/sdb/queue/add_random
echo "1" > /sys/block/sdb/queue/rq_affinity
echo "0" > /sys/block/sdb/queue/nomerges
echo "1024" > /sys/block/sdb/queue/nr_requests
echo "deadline" > /sys/block/sdc/queue/scheduler
echo "1024" > /sys/block/sdc/queue/read_ahead_kb
echo "0" > /sys/block/sdc/queue/rotational
echo "0" > /sys/block/sdc/queue/iostats
echo "0" > /sys/block/sdc/queue/add_random
echo "1" > /sys/block/sdc/queue/rq_affinity
echo "0" > /sys/block/sdc/queue/nomerges
echo "1024" > /sys/block/sdc/queue/nr_requests
echo "deadline" > /sys/block/sdd/queue/scheduler
echo "1024" > /sys/block/sdd/queue/read_ahead_kb
echo "0" > /sys/block/sdd/queue/rotational
echo "0" > /sys/block/sdd/queue/iostats
echo "0" > /sys/block/sdd/queue/add_random
echo "1" > /sys/block/sdd/queue/rq_affinity
echo "0" > /sys/block/sdd/queue/nomerges
echo "1024" > /sys/block/sdd/queue/nr_requests
echo "deadline" > /sys/block/sde/queue/scheduler
echo "1024" > /sys/block/sde/queue/read_ahead_kb
echo "0" > /sys/block/sde/queue/rotational
echo "0" > /sys/block/sde/queue/iostats
echo "0" > /sys/block/sde/queue/add_random
echo "1" > /sys/block/sde/queue/rq_affinity
echo "0" > /sys/block/sde/queue/nomerges
echo "1024" > /sys/block/sde/queue/nr_requests
echo "deadline" > /sys/block/sdf/queue/scheduler
echo "1024" > /sys/block/sdf/queue/read_ahead_kb
echo "0" > /sys/block/sdf/queue/rotational
echo "0" > /sys/block/sdf/queue/iostats
echo "0" > /sys/block/sdf/queue/add_random
echo "1" > /sys/block/sdf/queue/rq_affinity
echo "0" > /sys/block/sdf/queue/nomerges
echo "1024" > /sys/block/sdf/queue/nr_requests
echo "deadline" > /sys/block/mmcblk0/queue/scheduler
echo "1024" > /sys/block/mmcblk0/queue/read_ahead_kb
echo "0" > /sys/block/mmcblk0/queue/rotational
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0/queue/add_random
echo "1" > /sys/block/mmcblk0/queue/rq_affinity
echo "0" > /sys/block/mmcblk0/queue/nomerges
echo "1024" > /sys/block/mmcblk0/queue/nr_requests
sleep 1
# Perf HAL Tweaks Set Config
sleep 5
cat /proc/sys/kernel/perf_cpu_time_max_percent;
echo '5' > /proc/sys/kernel/perf_cpu_time_max_percent;
echo '8250' > /proc/sys/kernel/perf_event_max_sample_rate;
echo '1024' > /proc/sys/kernel/perf_event_mlock_kb;
echo '5' > /proc/sys/kernel/perf_event_paranoid;
cat /proc/sys/kernel/sched_boost;
sudo sysctl -w kernel.sched_boost=5
sudo sysctl -w kernel/sched_boost=5
echo '5' > /proc/sys/kernel/sched_boost;
restorecon -R /proc/sys/kernel/sched_boost;
cat /proc/sys/kernel/sched_cfs_boost;
echo '5' > /proc/sys/kernel/sched_cfs_boost;
restorecon -R /proc/sys/kernel/sched_cfs_boost;
cat /proc/sys/kernel/sched_freq_aggregate_threshold;
echo '0' > /proc/sys/kernel/sched_freq_aggregate_threshold;
restorecon -R /proc/sys/kernel/sched_freq_aggregate_threshold;
cat /proc/sys/kernel/timer_migration;
echo '0' > /proc/sys/kernel/timer_migration;
restorecon -R /proc/sys/kernel/timer_migration;
cat /sys/kernel/debug/perf_debug_tp/enabled;
echo '1' > /sys/kernel/debug/perf_debug_tp/enabled;
restorecon -R /sys/kernel/debug/perf_debug_tp/enabled;
sleep 1
# Force GPU for touch render
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;
sleep 1
#write /proc/sys/kernel/sched_lib_name "com.miHoYo., com.activision., UnityMain, libunity.so, libil2cpp.so"
write /proc/sys/kernel/sched_lib_name "com.miHoYo., com.activision., com.epicgames, com.dts., UnityMain, libunity.so, libil2cpp.so, libmain.so, libcri_vip_unity.so, libopus.so, libxlua.so, libUE4.so, libAsphalt9.so, libnative-lib.so, libRiotGamesApi.so, libResources.so, libagame.so, libapp.so, libflutter.so, libMSDKCore.so, libFIFAMobileNeon.so, libUnreal.so, libEOSSDK.so, libcocos2dcpp.so"
write /proc/sys/kernel/sched_lib_mask_force "240"
sleep 1
#Lmk tweaks
echo 2560,5120,11520,25600,35840,38400 > /sys/module/lowmemorykiller/parameters/minfree
#tweaks caf
if [[ -d "/sys/module/cpu_boost" ]]
then
	write "/sys/module/cpu_boost/parameters/input_boost_freq" 0:1800000
	write "/sys/module/cpu_boost/parameters/input_boost_ms" 230
fi
sleep 1
# Disable another logging like gpu,etc
write "/sys/module/rmnet_data/parameters/rmnet_data_log_level" "0"
write "/sys/kernel/debug/rpm_log" "0"
write "/d/tracing/tracing_on" "0"

# Disable Printk Logging mode
write "/sys/kernel/printk_mode/printk_mode" "0"

# Disable all kernel-panic
write "/proc/sys/kernel/hung_task_timeout_secs" "0"
write "/proc/sys/vm/panic_on_oom" "0"
write "/proc/sys/kernel/panic_on_oops" "0"
write "/proc/sys/kernel/panic" "0"
write "/proc/sys/kernel/softlockup_panic" "0"

for i in $(find /sys/ -name debug_mask); do
echo "0" > $i;
done
for i in $(find /sys/ -name debug_level); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ce); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ue); do
echo "0" > $i;
done
for i in $(find /sys/ -name enable_event_log); do
echo "0" > $i;
done
for i in $(find /sys/ -name log_ecn_error); do
echo "0" > $i;
done
for i in $(find /sys/ -name snapshot_crashdumper); do
echo "0" > $i;
done

for i in /sys/devices/virtual/block/*/queue/iosched; do
  echo "0" > $i/low_latency;
done;

if [ -e "/sys/module/xhci_hcd/parameters/wl_divide" ]; then
echo "N" > /sys/module/xhci_hcd/parameters/wl_divide
fi

# Kernel Tweaks
write /proc/sys/kernel/perf_cpu_time_max_percent "55"
write /proc/sys/kernel/perf_event_max_sample_rate"24000"
write /proc/sys/kernel/perf_event_mlock_kb "570"
write /proc/sys/kernel/sched_boost "0"
write /proc/sys/kernel/sched_downmigrate "95"
write /proc/sys/kernel/sched_group_upmigrate "160"
sleep 1
#f2fs tune
while [[ "$(cat /sys/fs/f2fs/*/cp_interval)" != "200" ]]; do
  echo 200 > /sys/fs/f2fs/*/cp_interval
  sleep 1
done

while [[ "$(cat /sys/fs/f2fs/*/gc_urgent_sleep_time)" != "50" ]]; do
  echo 50 > /sys/fs/f2fs/*/gc_urgent_sleep_time
  sleep 1
done

while [[ "$(cat /sys/fs/f2fs/*/iostat_enable)" != "1" ]]; do
  echo 1 > /sys/fs/f2fs/*/iostat_enable
  sleep 1
done

while [[ "$(cat /sys/block/sda/queue/discard_max_bytes)" != "134217728" ]]; do
  echo 134217728 > /sys/block/sda/queue/discard_max_bytes
  sleep 1
done

if [[ "$(cat /sys/fs/f2fs/*/gc_urgent_sleep_time)" = "50" ]]; then
  chmod 0444 /sys/fs/f2fs/*/gc_urgent_sleep_time
fi
sleep 1
