SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"


REPLACE="
"
print_modname() {
  ui_print "______________________________________________________"
  ui_print "                  VTweaks                "
  echo -n "- Date&Time: "
date "+%c"
sleep 2
ui_print "check information device"
sleep 2
ui_print "° Device           : $(getprop ro.product.name) "
sleep 0.5
ui_print "° Code name        : $(getprop ro.product.board) "
sleep 0.5
ui_print "° Android version  : $(getprop ro.build.version.release) "
sleep 0.5
ui_print "° SDK              : $(getprop ro.build.version.sdk) "
sleep 0.5
ui_print "° CPU_ABI          : $(getprop ro.product.cpu.abi) "
sleep 0.5
ui_print "° Hardware         : $(getprop ro.boot.hardware) "
sleep 0.5
ui_print "° Rom              : $(getprop ro.build.display.id) "
sleep 0.5
ui_print "° Fingerprint     : $(getprop ro.vendor.build.fingerprint) "
sleep 0.5
ui_print "° Kernel          : $(uname -r) "
sleep 0.5
busybox sleep 1
  ui_print "      Install script           "
sleep 1
busybox sleep 1
  ui_print "-------------------------------------------------- "
  ui_print "           Created by : Vendora    "
  ui_print "-------------------------------------------------- "
ui_print "installing Zram 3 GB "
sleep 2
ui_print " wait..."
sleep 3
ui_print " removing cache "
rm -rf /cache/dalvik-cache
rm -rf /data/cache
rm -rf /data/dalvik-cache
sleep 4
}


# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/system/bin/P0 0 0 0755 0755
  set_perm $MODPATH/system/bin/P1 0 0 0755 0755
  

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code

enforce_install_from_app() {
  if $BOOTMODE; then
    ui_print "- Installing from Magisk / KernelSU app"
  else
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery sucks"
    ui_print "! Please install from Magisk / KernelSU app"
    abort "*********************************************************"
  fi
}

check_magisk_version() {
  ui_print "- Magisk version: $MAGISK_VER_CODE"
  if [ "$MAGISK_VER_CODE" -lt 25000 ]; then
    ui_print "*********************************************************"
    ui_print "! Please install Magisk v25.0+ (25000+)"
    abort    "*********************************************************"
  fi
}

check_ksu_version() {
  ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
  if ! [ "$KSU_KERNEL_VER_CODE" ] || [ "$KSU_KERNEL_VER_CODE" -lt 10940 ]; then
    ui_print "*********************************************************"
    ui_print "! KernelSU version is too old!"
    ui_print "! Please update KernelSU to latest version"
    abort    "*********************************************************"
  elif [ "$KSU_KERNEL_VER_CODE" -ge 20000 ]; then
    ui_print "*********************************************************"
    ui_print "! KernelSU version abnormal!"
    ui_print "! Please integrate KernelSU into your kernel"
    ui_print "  as submodule instead of copying the source code"
    abort    "*********************************************************"
  fi
  if ! [ "$KSU_VER_CODE" ] || [ "$KSU_VER_CODE" -lt 10942 ]; then
    ui_print "*********************************************************"
    ui_print "! ksud version is too old!"
    ui_print "! Please update KernelSU Manager to latest version"
    abort    "*********************************************************"
  fi
}

check_zygisksu_version() {
  ZYGISKSU_VERSION=$(cat /data/adb/modules/zygisksu/module.prop | grep versionCode | sed 's/versionCode=//g')
  ui_print "- Zygisksu version: $ZYGISKSU_VERSION"
  if ! [ "$ZYGISKSU_VERSION" ] || [ "$ZYGISKSU_VERSION" -lt 45 ]; then
    ui_print "*********************************************************"
    ui_print "! Zygisksu version is too old!"
    ui_print "! Please update Zygisksu to latest version"
    abort    "*********************************************************"
  fi
}

CHECK1() {
D=$(getprop ro.product.device 2>/dev/null)
P=$(getprop ro.build.product 2>/dev/null)
VD=$(getprop ro.product.vendor.device 2>/dev/null)
VP=$(getprop ro.vendor.product.device 2>/dev/null)
DN=whyred

case "$DN" in
 "$D"|"$P"|"$VD"|"$VP")
  why=1
 ;;
 *)
  why=0
 ;;
esac

sleep $TIME

if [ "$why" == "0" ]; then
 ui_print "* Snapdragon only.!!!"
 abort "* Err Code1 : Installation Not Approved , Aborting !!! *"
elif [ "$why" == "1" ]; then
 ui_print "* Installation Approved Level 1 , Snapdragon detected *"
fi;
}

mountksu() {
    mount -t auto -o loop /data/adb/ksu/modules.img /data/adb/modules
}


CHECK2() {
if [ -e $SBIN/disable_thermal-throttle/disable ]; then
 Conf=1
elif [ -d $SBIN/disable_thermal-throttle ]; then
 Conf=1
elif [ -e $SBIN/FThermalXWH/disable ]; then
 Conf=1
elif [ -d $SBIN/FThermalXWH ]; then
 Conf=1
elif [ -e $SBIN/InfernoThermalsForWhyredv1/disable ]; then
 Conf=1
elif [ -d $SBIN/InfernoThermalsForWhyredv1 ]; then
 Conf=1
elif [ -e $SBIN/InfernoThermalsForWhyredv2/disable ]; then
 Conf=1
elif [ -d $SBIN/InfernoThermalsForWhyredv2 ]; then
 Conf=1
elif [ -e $SBIN/neothermalwhyred/disable ]; then
 Conf=1
elif [ -d $SBIN/neothermalwhyred ]; then
 Conf=1
elif [ -e $SBIN/uni-thermal-mod-whyred/disable ]; then
 Conf=1
elif [ -d $SBIN/uni-thermal-mod-whyred ]; then
 Conf=1
else
 Conf=0
fi;

sleep $TIME

if [ "Conf" == "1" ]; then
 ui_print "* No Thermal Detected..!!!"
 sleep 1
 abort "* Err Code : Installation Not Approved  , Aborting !!! *"
 sleep 1
elif [ "$Conf" == "0" ]; then
sleep 1
 ui_print "* Installation Approved Level  , Thermal Detected *"
 ui_print "$(getprop | grep thermal) "
 sleep 1
fi;
}


run_addon() {
    # Ganti dengan path ke skrip yang ingin dijalankan setelah reboot

    # Pastikan skrip memiliki izin eksekusi
        # Pindahkan skrip ke direktori post-fs-data.d
    chmod -R 0755 /data/local/tmp/
    chmod +x /data/local/tmp/addon.sh
    ui_print "Install addon"
    chmod +x "$ZIPFILE/addon/addon.sh*"
    unzip -oj "$ZIPFILE" 'addon/addon.sh*' -d /data/local/tmp/
    sleep 2
    ui_print "Mengatur Izin "
    # Pindahkan skrip ke direktori post-fs-data.d
    chmod -R 0755 /data/local/tmp/
    chmod +x /data/local/tmp/addon.sh
    ui_print "Skrip akan dijalankan setelah reboot."
}

hapus_addon() {
    cd /data/local/tmp/
    rm -rf/data/local/tmp/addon.sh
    sleep 1
    ui_print "add on sudah terhapus perubahan terjadi setelah reboot"
}


# Fungsi untuk menginstal modul
install_moduleP() {
    sleep 1
    CHECK2
    sleep 1
    # Check architecture
    if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x86" ] && [ "$ARCH" != "x64" ]; then
        abort "! Unsupported platform: $ARCH"
    else
        ui_print "- Device platform: $ARCH"
    fi
    print_modname
}

# Fungsi untuk menghapus modul
remove_moduleP() {
    cd /data/
    rm -rf /data/adb/modules/disable-thermal
    sleep 2
    rm -rf /data/local/tmp/addon
    ui_print "- module telah di un install "
    ui_print "- Penerapan akan dimulai setelah reboot."
    sleep 1
    exit
}


chmod -R 0755 $MODPATH/addon/Volume-Key-Selector/tools

chooseport_legacy() {
    # Keycheck binary by someone755 @Github, idea for code below by Zappo @xda-developers
    # Calling it first time detects previous input. Calling it second time will do what we want
    [ "$1" ] && local delay=$1 || local delay=60
    local error=false
    while true; do
        timeout 0 $MODPATH/addon/Volume-Key-Selector/tools/$ARCH32/keycheck
        timeout $delay $MODPATH/addon/Volume-Key-Selector/tools/$ARCH32/keycheck
        local sel=$?
        if [ $sel -eq 42 ]; then
            return 0
        elif [ $sel -eq 41 ]; then
            return 1
        elif $error; then
            abort "Error!"
        else
            error=true
            echo "Try again!"
        fi
    done
}

chooseport() {
    # Original idea by chainfire and ianmacd @xda-developers
    [ "$1" ] && local delay=$1 || local delay=60
    local error=false 
    while true; do
        local count=0
        while true; do
            timeout $delay /system/bin/getevent -lqc 1 2>&1 > $TMPDIR/events &
            sleep 0.5; count=$((count + 1))
            if (`grep -q 'KEY_VOLUMEUP *DOWN' $TMPDIR/events`); then
                return 0
            elif (`grep -q 'KEY_VOLUMEDOWN *DOWN' $TMPDIR/events`); then
                return 1
            fi
            [ $count -gt 60 ] && break
        done
        if $error; then
            echo "Trying keycheck method..."
            export chooseport=chooseport_legacy VKSEL=chooseport_legacy
            chooseport_legacy $delay
            return $?
        else
            error=true
            echo "Volume key not detected, try again!"
        fi
    done
}

InstallGki() {

VKSEL=chooseport


# Skrip instalasi modul Magisk
ui_print "Vendora tweaks" # Perubahan pada pesan selamat datang
ui_print " 1 Install module 2 Remove module"
ui_print "Volume up (+) to change selection"
ui_print "Volume down (-) to decide"
sleep 1

A=1 # Menu utama
while true; do
    case $A in
        1 ) TEXT="Install module";;
        2 ) TEXT="Remove module";;
    esac
    ui_print "$A - $TEXT"
    if $VKSEL; then
        A=$((A + 1))
    else
        break
    fi
    if [ $A -gt 2 ]; then
        A=1
    fi
done

ui_print ""
ui_print "You have selected: $A - $TEXT"

case $A in
    1 ) install_moduleP;;
    2 ) remove_moduleP;;
esac
}


addon_intaller() {
ui_print "Add-on installer" # Perubahan pada pesan selamat datang
ui_print "1 instal add-on 2 Hapus add-on"
ui_print "Volume up (+) to change selection"
ui_print "Volume down (-) to decide"
sleep 1

K=1 # Menu utama
while true; do
    case $K in
        1 ) TEXT="instal add-on";;
        2 ) TEXT="Hapus semua add-on";;
    esac
    ui_print "$A - $TEXT"
    if $VKSEL; then
        K=$((K + 1))
    else
        break
    fi
    if [ $K -gt 2 ]; then
        K=1
    fi
done

ui_print ""
ui_print "You have selected: $A - $TEXT"

case $K in
    1 ) run_addon;;
    2 ) hapus_addon;;
esac
}


Bypascharger() {
        # Skrip instalasi modul Magisk
ui_print " add auto charger and perf ?"
ui_print " addon for bypas charger"
ui_print " 1 Yes (Kalo mau umur batre lama )2 skip"
ui_print "Volume up (+) to change selection"
ui_print "Volume down (-) to decide"
sleep 1

VKSEL=chooseport

CR=1 # Menu utama
while true; do
    case $CR in
        1 ) TEXT="yes";;
        2 ) TEXT="skip";;
    esac
    ui_print "$B - $TEXT"
    if $VKSEL; then
        CR=$((CR + 1))
    else
        break
    fi
    if [ $CR -gt 2 ]; then
        CR=1
    fi
done

ui_print ""
ui_print "choose : $B - $TEXT"

case $CR in
    1 ) Bypaschargeryes;;
    2 ) Bypaschargerno;;
esac 
}

Bypaschargeryes() {
    # Ganti dengan path ke skrip yang ingin dijalankan setelah reboot

    # Pastikan skrip memiliki izin eksekusi
    sleep 1
    ui_print "Mengatur Izin "
    chmod -R 0755 /data/local/tmp/
    chmod +x /data/local/tmp/addon.sh
    sleep 1
    ui_print "Install addon"
    chmod +x "$ZIPFILE/addon/charger.sh*"
    unzip -oj "$ZIPFILE" 'addon/charger.sh*' -d /data/local/tmp/
    sleep 2
    # Pindahkan skrip ke direktori post-fs-data.d
    chmod -R 0755 /data/local/tmp/
    chmod +x /data/local/tmp/charger.sh
    ui_print "Bypass charger telah di tambahkan harap untuk melakukan reboot setelah instalasi module"

}

Bypaschargerno() {
    break

}


GpuCh() {
        # Skrip instalasi modul Magisk
ui_print " Changer renderer"
ui_print " Risk bootlop for mediatek recommended use 3 if got botlop"
ui_print " 1 SKIA GL 2 SKIAVK 3 Skiagl for mediatek"
ui_print "Volume up (+) to change selection"
ui_print "Volume down (-) to decide"
sleep 1

VKSEL=chooseport

B=1 # Menu utama
while true; do
    case $B in
        1 ) TEXT="SkiaGl";;
        2 ) TEXT="SkiaVk";;
        3 ) TEXT="SkiaGl mediatek";;
    esac
    ui_print "$B - $TEXT"
    if $VKSEL; then
        B=$((B + 1))
    else
        break
    fi
    if [ $B -gt 3 ]; then
        B=1
    fi
done

ui_print ""
ui_print "Render Gpu : $B - $TEXT"

case $B in
    1 ) SkiaGl;;
    2 ) SkiaVk;;
    3 ) KeluarH;;
esac

}


SkiaGl() {
    ui_print "-Install gpu "
    sleep 2
    unzip -oj "$ZIPFILE" 'GPUG/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-gpu render SkiaGL "
}

KeluarH() {
    ui_print "-Install gpu "
    sleep 2
    unzip -oj "$ZIPFILE" 'Mediatek/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-gpu render SkiaGL for Mediatek "
}

SkiaVk() {
    ui_print "-Install gpu "
    sleep 2
    unzip -oj "$ZIPFILE" 'GPUV/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-gpu render SkiaVK "
}
# Function to customize the module during installation
    TMPDIR=/dev/tmp
    MOUNTPATH=/dev/magisk_img

    # Default permissions
    umask 022

    # echo before loading util_functions
    ui_print() { echo "$1"; }

    require_new_magisk() {
        ui_print "***********************************"
        ui_print " Please install the latest Magisk! "
        ui_print "***********************************"
        exit 1
    }

    imageless_magisk() {
        [ $MAGISK_VER_CODE -gt 25000 ]
        return $?
    }

    ##########################################################################################
    # Environment
    ##########################################################################################

    mount /data 2>/dev/null

    # Load utility functions
    if [ -f /data/adb/magisk/util_functions.sh ]; then
        . /data/adb/magisk/util_functions.sh
        NVBASE=/data/adb
    else
        require_new_magisk
    fi

    # Preperation for flashable zips
    setup_flashable

    # Mount partitions
    mount_partitions

    # Detect version and architecture
    api_level_arch_detect

    # Setup busybox and binaries
    $BOOTMODE && boot_actions || recovery_actions

    ##########################################################################################
    # Preparation
    ##########################################################################################

    # Extract common files
    unzip -oj "$ZIPFILE" module.prop uninstall.sh 'common/*' -d $TMPDIR >&2

    if imageless_magisk; then
        $BOOTMODE && MODDIRNAME=modules_update || MODDIRNAME=modules
        MODULEROOT=$NVBASE/$MODDIRNAME
    else
        $BOOTMODE && IMGNAME=magisk_merge.img || IMGNAME=magisk.img
        IMG=$NVBASE/$IMGNAME
        request_zip_size_check "$ZIPFILE"
        mount_magisk_img
        MODULEROOT=$MOUNTPATH
    fi

    MODID=$(grep_prop id $TMPDIR/module.prop)
    MODPATH=$MODULEROOT/$MODID

    ui_print "******************************"
    ui_print "Powered by Vendora"
    ui_print "******************************"
    ui_print ""

    ##########################################################################################
    # Install
    ##########################################################################################

    # Create mod paths
    rm -rf $MODPATH 2>/dev/null
    mkdir -p $MODPATH

SKIPUNZIP=1
    enforce_install_from_app
    if [ "$KSU" ]; then
        check_ksu_version
        check_zygisksu_version
        mountksu
    else
        check_magisk_version
    fi
    sleep 1
    on_install
    sleep 1
    Bypascharger
    sleep 1
    GpuCh
    sleep 1
    addon_intaller
    sleep 1
    InstallGki
    sleep 1
    ui_print "- Setting permissions"
    set_permissions

    # Remove placeholder
    rm -f $MODPATH/system/placeholder 2>/dev/null

    # Custom uninstaller
    [ -f $TMPDIR/uninstall.sh ] && cp -af $TMPDIR/uninstall.sh $MODPATH/uninstall.sh

    # Auto Mount
    if imageless_magisk; then
        $SKIPMOUNT && touch $MODPATH/skip_mount
    else
        $SKIPMOUNT || touch $MODPATH/auto_mount
    fi
    sleep 1
    # prop files
    $PROPFILE && cp -af $TMPDIR/system.prop $MODPATH/system.prop
    sleep 1
    # Module info
    cp -af $TMPDIR/module.prop $MODPATH/module.prop
    if $BOOTMODE; then
        # Update info for Magisk Manager
        if imageless_magisk; then
            mktouch $NVBASE/modules/$MODID/update
            cp -af $TMPDIR/module.prop $NVBASE/modules/$MODID/module.prop
        else
            mktouch /sbin/.magisk/img/$MODID/update
            cp -af $TMPDIR/module.prop /sbin/.magisk/img/$MODID/module.prop
        fi
    fi

    # service mode scripts
    $LATESTARTSERVICE && cp -af $TMPDIR/service.sh $MODPATH/service.sh

    # Handle replace folders
    for TARGET in $REPLACE; do
        mktouch $MODPATH$TARGET/.replace
    done

    ##########################################################################################
    # Finalizing
    ##########################################################################################

    cd /
    imageless_magisk || unmount_magisk_img
    $BOOTMODE || recovery_cleanup
    rm -rf $TMPDIR $MOUNTPATH

    ui_print "- Vendora"
exit 0