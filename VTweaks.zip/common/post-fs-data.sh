MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

# Set zram configurations
resetprop -n ro.vendor.qti.config.zram true