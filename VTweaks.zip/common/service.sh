# Universal Thermal Disabler
echo 0 > /sys/class/thermal/thermal_zone*/mode
sleep 1
# Thermal Stop Setprop Methode
setprop init.svc.android.thermal-hal stopped
setprop init.svc.thermal stopped
setprop init.svc.thermal-managers stopped
setprop init.svc.thermal_manager stopped
setprop init.svc.thermal_mnt_hal_service stopped
setprop init.svc.thermal-engine stopped
setprop init.svc.mi-thermald stopped
setprop init.svc.thermalloadalgod stopped
setprop init.svc.thermalservice stopped
setprop init.svc.thermal-hal stopped
setprop init.svc.vendor.thermal-symlinks
setprop init.svc.android.thermal-hal stopped
setprop init.svc.vendor.thermal-hal stopped
setprop init.svc.thermal-manager stopped
setprop init.svc.vendor-thermal-hal-1-0 stopped
setprop init.svc.vendor.thermal-hal-1-0 stopped
setprop init.svc.vendor.thermal-hal-2-0.mtk stopped
setprop init.svc.vendor.thermal-hal-2-0 stopped
sleep 1
# Disable Fsync
chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo "N" > /sys/module/sync/parameters/fsync_enable
# Thermal Stop Semi-auto Methode
sleep 12
stop logd
sleep 1
stop vendor.thermal-engine
sleep 1
stop vendor.thermal_manager
sleep 1
stop vendor.thermal-manager
sleep 1
stop vendor.thermal-hal-2-0
sleep 1
stop vendor.thermal-symlinks
sleep 1
stop thermal_mnt_hal_service
sleep 1
stop thermal
sleep 1
stop mi_thermald
sleep 1
stop thermald
sleep 1
stop thermalloadalgod
sleep 1
stop thermalservice
sleep 1
stop sec-thermal-1-0
sleep 1
stop debug_pid.sec-thermal-1-0
sleep 1
stop thermal-engine
sleep 1
stop vendor.thermal-hal-1-0
sleep 1
stop android.thermal-hal
sleep 1
stop vendor-thermal-1-0
sleep 1
stop thermal-hal
sleep 1
stop android.thermal-hal
sleep 1
#zram
swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo 3221225472 > /sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon  /dev/block/zram0
sleep 10
#addon on
chmod 755 /data/adb/modules/disable-thermal/service.sh
chmod +x /data/local/tmp/addon.sh
chmod +x /data/local/tmp/charger.sh
su -c 'sh /data/local/tmp/addon.sh'
sleep 1
su -c 'sh /data/local/tmp/charger.sh'
#Fstrim partitions
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /preload
sleep 1
# Disable Find My Device (in order to have optimized GMS for Android 9 or later);
su -c "pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver"
sleep 40

